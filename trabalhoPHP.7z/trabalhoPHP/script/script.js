function Num(num) {
   if (typeof s == 'undefined') {
      document.senhaform.senha.value = '';
   }
   document.senhaform.senha.value = document.senhaform.senha.value + num;
   s = 1;
}

function Limpar() {
   document.senhaform.senha.value = '';
   delete s;
}
